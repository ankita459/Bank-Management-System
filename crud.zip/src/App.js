
import './App.css';
import Home from './Components/Home';
import Login from './Components/Login';
import Signup from './Components/Signup.js';
import { Routes, Route, BrowserRouter, Router } from 'react-router-dom';
import Homepage from './Components/Homepage';
import Footer from './Components/Footer';
import Mainbody from './Components/Mainbody';
import Products from './Components/Products';
import Table from './Components/Table';
import AddProduct from './Components/AddProduct';
import Welcome from './Components/Welcome';


function App() {
  return (
    <div className="App">


      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Login />} ></Route>
          <Route path='/welcome' element={<Welcome />} ></Route>
          <Route path='/signup' element={<Signup />} ></Route>
          <Route path='/login' element={<Login />} ></Route>
          <Route path='/home' element={<Home />} ></Route>
          <Route path='/products' element={<Products />} ></Route>
          <Route path='/table' element={<Table />} ></Route>
          <Route path='/addproduct' element={<AddProduct />} ></Route>


        </Routes>
      </BrowserRouter>

      {/* <Homepage />
      <Mainbody />
      <Footer /> */}
      {/* <Signup />
      <Login />
      <Home /> */}
    </div>
  );
}

export default App;
