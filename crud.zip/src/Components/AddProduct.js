import Home from "./Home";
import { useState } from "react";
import '../App.css'

const AddProduct = () => {
    const [addbankName, setAddbankName] = useState('');
    const [addaccNumber, setAddaccNumber] = useState(0);
    const [addaccountBalance, setAddaccountBalance] = useState(0);
    const [addtype, setAddtype] = useState(0);
    const [addstatus, setAddstatus] = useState(0);
    const [showModal2, setShowModal2] = useState(false);
    const addProduct = () => {
        let data = {
            bankName: addbankName,
            accNumber: addaccNumber,
            accountBalance:addaccountBalance,
            type:addtype,
            status:addstatus
        }
        fetch("http://localhost:8098/api/v1/BankDetail", {
            method: "POST",
            body: JSON.stringify(data),
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            }
        }).then(response => response.json())
            .then(json => console.log(json))

    }
    return (
        <div>
            <Home />
            <button
                className="bg-blue-500 text-white active:bg-blue-600 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                type="button"
                onClick={() => { setShowModal2(true); }}
                id="addbutton"
            >   
                Add BankDetail
            </button>


            {showModal2 ? (
                <>
                    <div
                        className="justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none"
                    >
                        <div className="relative w-auto my-6 mx-auto max-w-3xl">
                            {/*content*/}
                            <div className="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none">
                                {/*header*/}
                                <div className="flex items-start justify-between p-5 border-b border-solid border-slate-200 rounded-t">
                                    <h3 className="text-3xl font-semibold">
                                        Add BankDetail
                                    </h3>
                                    <button
                                        className="p-1 ml-auto bg-transparent border-0 text-black opacity-5 float-right text-3xl leading-none font-semibold outline-none focus:outline-none"
                                        onClick={() => setShowModal2(false)}
                                    >
                                        <span className="bg-transparent text-black opacity-5 h-6 w-6 text-2xl block outline-none focus:outline-none">
                                            ×
                                        </span>
                                    </button>
                                </div>
                                {/*body*/}
                                <div className="relative p-6 flex-auto">

                                    {/* <h3 className="mb-4 text-xl font-medium text-gray-900 dark:text-white">
                                                    Add product
                                                </h3> */}
                                    <form className="space-y-6" action="#">
                                        <div>
                                            <label
                                                htmlFor="name"
                                                className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                                            >
                                                Bank Name
                                            </label>
                                            <input
                                                type="name"
                                                name="bankname"
                                                id="bankName"
                                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white"
                                                placeholder="Enter Bank Name"
                                                required=""
                                                onChange={(e) => setAddbankName(e.target.value)}
                                            />
                                        </div>
                                        <div>
                                            <label
                                                htmlFor="number"
                                                className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                                            >
                                                Account Number
                                            </label>
                                            <input
                                                type="number"
                                                name="number"
                                                id="accNumber"
                                                placeholder="Enter Account Number"
                                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white"
                                                required=""
                                                onChange={(e) => setAddaccNumber(e.target.value) }
                                            />
                                        </div>
                                        <div>
                                            <label
                                                htmlFor="name"
                                                className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                                            >
                                                Account Balance
                                            </label>
                                            <input
                                                type="name"
                                                name="name"
                                                id="accountBalance"
                                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white"
                                                placeholder="Enter Balance"
                                                required=""
                                                onChange={(e) => setAddaccountBalance(e.target.value)}
                                            />
                                        </div>

                                        <div>
                                            <label
                                                htmlFor="name"
                                                className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                                            >
                                                Account Type
                                            </label>
                                            <input
                                                type="name"
                                                name="name"
                                                id="type"
                                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white"
                                                placeholder="Enter Account Type"
                                                required=""
                                                onChange={(e) => setAddtype(e.target.value)}
                                            />
                                        </div>

                                        <div>
                                            <label
                                                htmlFor="name"
                                                className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                                            >
                                                Account status
                                            </label>
                                            <input
                                                type="name"
                                                name="name"
                                                id="status"
                                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white"
                                                placeholder="Enter status"
                                                required=""
                                                onChange={(e) => setAddstatus(e.target.value)}
                                            />
                                        </div>
                                        <br></br>

                                        <button
                                            type="submit"
                                            className="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                            onClick={() => addProduct()}
                                        >
                                            Add
                                        </button>

                                    </form>

                                </div>
                                {/*footer*/}
                                <div className="flex items-center justify-end p-6 border-t border-solid border-slate-200 rounded-b">
                                    <button
                                        className="text-red-500 background-transparent font-bold uppercase px-6 py-2 text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                                        type="button"
                                        onClick={() => setShowModal2(false)}
                                    >
                                        Close
                                    </button>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="opacity-25 fixed inset-0 z-40 bg-black"></div>
                </>
            ) : null}
        </div>
    );
}

export default AddProduct;