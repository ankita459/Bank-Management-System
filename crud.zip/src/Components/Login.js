import { Link, Navigate, Router, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Routes, Route, BrowserRouter } from 'react-router-dom';

// import '../App.css';
import './Login.css'
const Login = () => {





    const [email, setemail] = useState('');
    const [password, setPassword] = useState('');



    function signup() {

        let data = {
            email: email,
            password: password
        }
        fetch(' http://localhost:8098/api/v1/BankDetail', {
            method: "POST",
            body: JSON.stringify(data),
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            }
        }).then(response => response.json())
            .then(json => console.log(json))

        alert("Login successfull ")
        navigate('/home');


    }






    const [email1, setemail1] = useState('');
    const [password1, setPassword1] = useState('');

    const navigate = useNavigate();

    const [redirect, setRedirect] = useState(false);

    let data = {
        email: email1,
        password: password1
    }
    console.log(email1 + password1 + data.email)

    let flag = false;
    const Logins = () => {
        fetch('http://localhost:8098/api/v1/BankDetail', {
            method: "POST",
            body: JSON.stringify(data),
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            }
        }).then(response => { return response.text() })
            .then(text => {
                if (text === 'valid') {

                    alert("login successfull");
                    navigate('/home');

                    //setRedirect(true);
                }
                else {
                    alert("enter valid details")
                }
            })



    }



    return (
        <div id='signup-div'>

            {/* <h2>Login</h2>
            Username:<input type='text' onChange={(e) => { setUsername1(e.target.value) }}></input><br /><br></br>
            Password:<input type="password" onChange={(e) => { setPassword1(e.target.value) }}></input><br></br><br></br>
            <button onClick={Logins}  >Login</button><br></br>

            Username:<input type='text' onChange={(e) => { setUsername(e.target.value) }}></input><br /><br></br>
            Password:<input type="password" onChange={(e) => { setPassword(e.target.value) }}></input><br></br><br></br>
            <button onClick={signup} >Register</button><br></br>

            <Link id="link" to="/signup">Not Registered! Signup</Link>
            {redirect ? <Link to="/home"></Link> : <Link to="/login"></Link>} */}

            <div className="body">
                <div className="main">
                    <input type="checkbox" id="chk" aria-hidden="true" />

                    <div className="signup">

                        <label className="label1" for="chk" aria-hidden="true">Login</label>

                        <input type="text" placeholder="Email" onChange={(e) => { setemail(e.target.value) }} />
                        <input type="password" placeholder="Password" onChange={(e) => { setPassword(e.target.value) }} />
                        <button className='button1' onClick={() => signup()}>Login</button>

                    </div>

                    
                </div>
            </div>






        </div>
    )
}
export default Login;