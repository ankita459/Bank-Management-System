const Welcome = () => {
    return (
        <div>
            <h1 className='text'>Bank CRUD</h1>
        </div>
        
    );
}

export default Welcome;