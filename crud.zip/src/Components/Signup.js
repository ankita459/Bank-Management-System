import { useState } from 'react';
import { Link } from 'react-router-dom';
import '../App.css';
const Signup = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');



    function signup() {

        let data = {
            email: username,
            password: password
        }
        fetch(' http://localhost:8098/api/v1/BankDetail', {
            method: "POST",
            body: JSON.stringify(data),
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            }
        }).then(response => response.json())
            .then(json => console.log(json))

        alert("signup successful go to login")


    }
    return (
        <div id='signup-div'>
            <h2>Login</h2>
            Username:<input type='text' onChange={(e) => { setUsername(e.target.value) }}></input><br /><br></br>
            Password:<input type="password" onChange={(e) => { setPassword(e.target.value) }}></input><br></br><br></br>
            <button onClick={signup} >Register</button><br></br>

            <Link id="link" to="/login">Already Registered! login</Link>

        </div>
    )
}
export default Signup;