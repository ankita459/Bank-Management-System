import React from 'react';
import App from './App';


import { shallow, configure, mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import Adapter from 'enzyme-adapter-react-16';
import Login from './Components/Login';
import { BrowserRouter as Router } from 'react-router-dom';
import Home from './Components/Home';
import Products from './Components/Products';
import Mainbody from './Components/Mainbody';
import Footer from './Components/Footer';
configure({ adapter: new Adapter() });

describe('MyComponent', () => {

  // it('renders component without crash', () => {
  //   shallow(<App />);

  // });
  it('renders home  without crash', () => {
    shallow(<Home />);

  });
  it('renders Footer  without crash', () => {
    shallow(<Footer />);

  });









});


